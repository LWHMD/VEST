#Torque script options, you can modify.
#PBS -S /bin/bash
#PBS -N vasp.5.4.4
#PBS -l nodes=1:ppn=32
#PBS -j oe
#PBS -V

#Torque built-in environment variables, don't need to modify.
cd $PBS_O_WORKDIR
echo Name of submitting user : $PBS_O_LOGNAME
echo Script shell : $PBS_O_SHELL
echo Language variable for job : $PBS_O_LANG
echo Active port for MOM daemon : $PBS_MOMPORT
echo Home directory of submitting user : $PBS_O_HOME
echo "Job's submission directory" : $PBS_O_WORKDIR
echo Host on which job script is currently running : $PBS_O_HOST
echo User specified jobname : $PBS_JOBNAME
echo Unique pbs job id : $PBS_JOBID
echo Job queue : $PBS_QUEUE
echo Number of nodes allocated to the job : $PBS_NUM_NODES
echo Number of procs per node allocated to the job : $PBS_NUM_PPN
echo "Number of execution slots (cores) for the job" : $PBS_NP
echo File containing line delimited list on nodes allocated to the job : `sort -u $PBS_NODEFILE`
echo Path variable used to locate executables within job script : $PBS_O_PATH

#Set environment variables, don't need to modify.
source /share/scripts/vasp.5.4.4.env

#Program run command, don't need to modify.
echo The job start time at: `date`
#TCP/IP

mpirun -machinefile $PBS_NODEFILE -env I_MPI_HYDRA_DEBUG 3 -genv I_MPI_FABRICS shm:ofa /home/lwang/bin/QE-instal/bin/pw.x < band.in > band.out 2>&1
mpirun -machinefile $PBS_NODEFILE -env I_MPI_HYDRA_DEBUG 3 -genv I_MPI_FABRICS shm:ofa /home/lwang/bin/QE-instal/bin/bands.x < bandx.in > bandx.out 2>&1

echo The job end time at: `date`
